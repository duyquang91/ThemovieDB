import SwiftUI
import Repositories
import ImageServices
import Combine

public struct MovieCellView: View {
    public var movie: MovieModel
    @ObservedObject var imageLoader = ImageLoader()
    private var disposeBags = Set<AnyCancellable>()
    
    public var body: some View {
        HStack(alignment: .top, content: {
            Image(uiImage: imageLoader.image ?? UIImage())
                
            VStack(alignment: .leading, content: {
                Text(movie.title).font(.headline)
                Text(movie.overview).font(.subheadline).foregroundColor(.gray).lineLimit(4)
            })
        })
    }
    
    public init(movie: MovieModel) {
        self.movie = movie
        if let imagePath = movie.poster_path {
            imageLoader.load(imageUrlString: urlHostImage + "/w92" + imagePath)
        }
    }
}
