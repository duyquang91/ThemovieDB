import Foundation

public let urlHost = "https://api.themoviedb.org/3/"
public let urlHostImage = "https://image.tmdb.org/t/p"
public let apiKey = "57a1c5e4e124f2a16e4c7db4b7d6cdf3"

enum APIPath: String {
    case search = "search/movie"
}

enum APIRequest {
    case searchRequest(String)
    
    var urlRequest: URLRequest {
        switch self {
        case .searchRequest(let keyWord):
            var urlComponents = URLComponents(string: urlHost)!
            urlComponents.path.append(APIPath.search.rawValue)
            urlComponents.queryItems = [URLQueryItem(name: "api_key", value: apiKey), URLQueryItem(name: "query", value: keyWord)]
            return URLRequest(url: urlComponents.url!)
        }
        
    }
}
