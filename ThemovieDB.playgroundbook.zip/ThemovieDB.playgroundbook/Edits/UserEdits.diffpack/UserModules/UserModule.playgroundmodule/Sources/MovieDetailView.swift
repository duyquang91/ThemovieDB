import SwiftUI
import Combine
import ImageServices
import Repositories

public struct MovieDetailView: View {
    @ObservedObject var imageLoader = ImageLoader()
    let movie: MovieModel
    
    public init(movie: MovieModel) {
        self.movie = movie
        if let backdropUrl = movie.backdrop_path {
            imageLoader.load(imageUrlString: urlHostImage + "/original" + backdropUrl)
        }
    }
    
    public var body: some View {
        VStack(alignment: .leading) {
            Image(uiImage: imageLoader.image ?? UIImage()).resizable()
            Text(movie.title).font(.largeTitle)
            Text("Release date: " + movie.release_date).font(.headline).foregroundColor(.gray).underline()
            Text("Votes: \(movie.vote_average)").font(.headline).foregroundColor(.gray).underline()
            Text(movie.overview).font(.subheadline).foregroundColor(.gray).italic()
        }.padding()
    }
}
