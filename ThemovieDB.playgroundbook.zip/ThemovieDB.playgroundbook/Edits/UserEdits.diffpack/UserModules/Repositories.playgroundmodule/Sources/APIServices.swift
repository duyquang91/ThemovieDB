import Foundation
import Combine

final public class APIEngine {
    public static func searchMoviePublisher(keyWord: String) -> AnyPublisher<MovieResponseModel, Error> {
        return URLSession.shared.dataTaskPublisher(for: APIRequest.searchRequest(keyWord).urlRequest)
        .map { $0.data }
        .decode(type: MovieResponseModel.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}
