
import Foundation

public struct MovieResponseModel: Decodable {
    public var results: [MovieModel]
}

public struct MovieModel: Decodable, Hashable {
    public var id: Int
    public var title: String
    public var overview: String
    public var poster_path: String?
    public var backdrop_path: String?
    public var release_date: String
    public var vote_average: Double
}
