
import Foundation
import Combine
import UIKit
import SwiftUI

public class ImageLoader: ObservableObject {
    @Published public var image: UIImage?
    private var disposeBag = Set<AnyCancellable>()
    
    public init() {}
    
    public func load(imageUrlString: String) {
    URLSession.shared.dataTaskPublisher(for: URLRequest(url: URL(string: imageUrlString)!, cachePolicy: .returnCacheDataElseLoad))
    .tryMap { UIImage(data: $0.data) }
        .sink(receiveCompletion: { [weak self] _ in
            self?.objectWillChange.send()
        }) { [weak self] image in
            self?.image = image
            
        }.store(in: &disposeBag)
}
}
