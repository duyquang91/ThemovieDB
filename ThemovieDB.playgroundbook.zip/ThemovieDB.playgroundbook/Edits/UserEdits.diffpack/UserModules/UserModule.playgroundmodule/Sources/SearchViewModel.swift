import Repositories
import Combine
import SwiftUI

public class SearchViewModel: ObservableObject {
    // Inputs
    @Published public var keyWord: String = ""
    
    // Outputs
    @Published public var movies: [MovieModel] = []
    @Published public var isLoading: Bool = false
    @Published public var error: Error?
    
    private var disposeBag = Set<AnyCancellable>()
    
    public init() {
        $keyWord.dropFirst()
            .debounce(for: 1, scheduler: RunLoop.current)
            .removeDuplicates()
            .sink(receiveValue: { [weak self] text in
            guard let self = self else { return }
            APIEngine.searchMoviePublisher(keyWord: text)
                .handleEvents(receiveSubscription: { [weak self] _ in
                self?.isLoading = true
                    self?.error = nil
                }, receiveCompletion: { [weak self] completed in
                    self?.isLoading = false
                    self?.objectWillChange.send()
            })
                .receive(on: RunLoop.main)
                .sink(receiveCompletion: { [weak self] completed in
                    switch completed {
                    case .finished:
                        self?.error = nil 
                        
                    case .failure(let error):
                        self?.error = error
                        self?.movies = []
                    }
                    }, receiveValue: { [weak self] movieModel in
                        self?.movies = movieModel.results
                }).store(in: &self.disposeBag)
        }).store(in: &disposeBag)
    }
}
